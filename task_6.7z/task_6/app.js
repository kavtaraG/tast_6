function asnc(url){
    return new Promise((resolve, reject)=>{
        fetch(url)
        .then(response => response.json())
        .then(returnedResponse =>{
            console.log('returned', returnedResponse);
            if(returnedResponse.code === 200){
                resolve(returnedResponse);
            }else{
                throw 'Error has been detected: ' + returnedResponse.code;
            }     
    })
    .catch(err => {
        reject(err);
    })
})
    }

// asnc('https://reqres.in/api/users?_quantity_5')
asnc('app3.json')
.then(response=>{
    console.log(response);
    response.data.forEach(item =>{
        const ul = document.body;
        const li = document.createElement('li');
        ul.appendChild(li);
        li.textContent = item.email; 
    });
})
.catch(err => {
    const body = document.body;
    const p = document.createElement('p');
    p.textContent = err;
    p.style.color = 'red';
    body.appendChild(p);
})

asnc('https://fakerapi.it/api/v1/books?_quantity=5')

.then(response=>{
    // console.log(response);
    response.data.forEach(item =>{
        const ul = document.body;
        const li = document.createElement('li');
        ul.appendChild(li);
        li.textContent = item.title; 
    });
})
.catch(err => {
    const body = document.body;
    const p = document.createElement('p');
    p.textContent = err;
    p.style.color = 'red';
    body.appendChild(p);
})

asnc('app.json?_quantity=5') //nbg
.then(response=>{
    console.log(response);
    response.data.forEach(item =>{
        const ul = document.body;
        const li = document.createElement('li');
        ul.appendChild(li);
        // li.textContent = item.currencies.code; 
        li.textContent = item.currencies.rate; 
    });
})
.catch(err => {
    const body = document.body;
    const p = document.createElement('p');
    p.textContent = err;
    p.style.color = 'red';
    body.appendChild(p);
});

// asnc('https://jsonplaceholder.typicode.com/posts')
asnc('app2.json')
.then(response=>{
    console.log(response);
    response.data.forEach(item =>{
        const ul = document.body;
        const li = document.createElement('li');
        ul.appendChild(li);
        li.textContent = item.userId; 
    });
})
.catch(err => {
    const body = document.body;
    const p = document.createElement('p');
    p.textContent = err;
    p.style.color = 'red';
    body.appendChild(p);
});


//დავალება2
//პრომისი არის დაბრუნებული ობიექტი, რომელიც გვიჩვენებს წარმატებული თუ წარუმატებელი ოპერაციის 
//ასინქრონულ ფუნქციას.
//პრიმისს შეიძლება ქონდეს რამდენიმე არგუმენტი და მისი ქოლბექი, შეიძლება რამდენიმე .then()-ში იქნეს
//ჩაწერილი.
